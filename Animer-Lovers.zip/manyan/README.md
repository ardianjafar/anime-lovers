
# Submission Android Expert Dicoding

Aplikasi Anime-Lover made for Submission Dicoding Android Expert

this project implement about studying android studio and the output is build simple app and also implements useful library like shimmer, lottie, leakcannary, etc.

Thanks for dicoding for module / materials.


## Thanks For

 - [Dicoding](https://dicoding.com)
 - [Android Studio](https://developer.android.com/)





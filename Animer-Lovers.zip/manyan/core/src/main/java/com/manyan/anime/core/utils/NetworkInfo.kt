package com.manyan.anime.core.utils

import com.manyan.anime.core.BuildConfig

object NetworkInfo {
    const val BASE_URL = BuildConfig.BASE_URL
}
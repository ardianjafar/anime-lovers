package com.manyan.anime.core.domain.model

data class CoverImage(
    val small: String?,
    val large: String?,
    val original: String?,
)

package com.manyan.anime.core.domain.model

data class PosterImage(
    val medium: String?,
    val large: String?,
    val original: String?,
)

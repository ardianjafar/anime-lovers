package com.manyan.anime.core.domain.model

data class Titles(
    val en: String?,
    val enJp: String?,
    val jaJp: String?
)

